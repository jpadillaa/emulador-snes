---
name: Native Emulator Pro
colors:
  surface: '#121317'
  surface-dim: '#121317'
  surface-bright: '#38393d'
  surface-container-lowest: '#0d0e12'
  surface-container-low: '#1a1b1f'
  surface-container: '#1e1f23'
  surface-container-high: '#292a2e'
  surface-container-highest: '#343539'
  on-surface: '#e3e2e7'
  on-surface-variant: '#c1c6d7'
  inverse-surface: '#e3e2e7'
  inverse-on-surface: '#2f3034'
  outline: '#8b90a0'
  outline-variant: '#414755'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e69'
  primary-container: '#4b8eff'
  on-primary-container: '#00285c'
  inverse-primary: '#005bc1'
  secondary: '#c8c6c5'
  on-secondary: '#303030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b5b4'
  tertiary: '#c8c6c8'
  on-tertiary: '#303032'
  tertiary-container: '#919092'
  on-tertiary-container: '#29292b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1b1c'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#e4e2e4'
  tertiary-fixed-dim: '#c8c6c8'
  on-tertiary-fixed: '#1b1b1d'
  on-tertiary-fixed-variant: '#474649'
  background: '#121317'
  on-background: '#e3e2e7'
  surface-variant: '#343539'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 16px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  margin-window: 20px
  gutter-sidebar: 12px
  padding-control: 8px
  stack-gap: 16px
  section-gap: 32px
---

## Brand & Style

The design system is engineered to feel like a first-party utility on macOS. It prioritizes the **Corporate / Modern** aesthetic, strictly adhering to the Apple Human Interface Guidelines (HIG). The brand personality is professional, utilitarian, and high-performance, ensuring that the emulator feels like a seamless extension of the operating system rather than a third-party skin.

The user experience focuses on "content-first" principles, where the software recedes into the background to let the emulation take center stage. Key characteristics include:
- **Native Fidelity:** Use of system-standard translucency (vibrancy) and SF Symbols.
- **Precision:** Tight alignment and standard macOS control sizing.
- **High-Performance Aura:** A monochrome-heavy palette that suggests speed and stability.

## Colors

This design system utilizes a system-centric color palette optimized for Dark Mode. It relies on the macOS semantic color system to ensure accessibility and visual harmony with the OS.

- **Accent:** Apple Blue (#007AFF) is used sparingly for primary actions, focus rings, and active states.
- **Backgrounds:** A tiered hierarchy of grays. The main window uses a deep black (#000000) or near-black for the "stage," while sidebars and toolbars utilize macOS-standard vibrancy (translucency).
- **Foregrounds:** Text is primarily SF Pro White (Primary) and Secondary Gray for labels, providing a clear information hierarchy.
- **Vibrancy:** Background blur is applied to sidebars and toolbars (Material: Thick/Regular) to ground the app within the desktop environment.

## Typography

The typography system uses **Inter** (as the closest web-safe/open alternative to San Francisco) to maintain a systematic, utilitarian appearance.

- **Hierarchical Scale:** Headlines are reserved for view titles and game titles. Body text is kept at the macOS standard 13px for maximum legibility in toolsets.
- **Labels:** Control mapping and sidebar items use 12px or 11px weights to mimic native Inspector panels.
- **Monospaced Accents:** For technical data (FPS, frame counts), use a monospaced variant to ensure alignment.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid** model typical of professional macOS apps:

- **Sidebar:** A fixed-width (220px - 280px) left or right sidebar with standard macOS list styling.
- **The Stage:** The central content area (the emulator window) is fluid but maintains aspect-ratio constraints (4:3 or 8:7) with generous "letterboxing" whitespace.
- **Toolbars:** 52px high top toolbars containing SF Symbol buttons with 12px internal padding.
- **Rhythm:** An 8px grid governs all spacing. Section headers are separated from their content by 16px, and major UI regions by 32px.

## Elevation & Depth

Depth is established through **Tonal Layers** and **Vibrancy**, rather than drop shadows.

- **Level 0 (Base):** The desktop wallpaper, visible through the sidebar's translucency.
- **Level 1 (Content):** The main window surface, using a dark gray or black background to focus the eye on the game.
- **Level 2 (Panels):** Control mapping boxes and input fields use a slightly lighter gray (#2C2C2E) with a subtle 1px border (#3A3A3C) to define edges.
- **Overlays:** Modals and popovers use standard macOS system shadows (large blur, low opacity) and backdrop filters to blur underlying content.

## Shapes

The design system adopts the **Soft** (Level 1) roundedness characteristic of modern macOS (Big Sur and later).

- **Outer Enclosure:** Main window corners follow the system standard (approx. 10-12px).
- **Inner Controls:** Buttons and input fields use a 5px corner radius.
- **Selection States:** Hover and active states in the sidebar use a 6px radius, matching the standard sidebar list item style.
- **Game Tiles:** If a library view is used, game box art should have a subtle 4px radius to feel modern but structured.

## Components

### Toolbars & Buttons
- **Toolbar Buttons:** Use SF Symbols centered in a 32x32px hit area. Default state has no background; hover state shows a subtle gray circle.
- **Standard Buttons:** High-contrast gray with white text. Primary actions use the Accent Blue.

### Sidebar Navigation
- **Source List Style:** Transparent background with vibrant blur. Use SF Symbols for icons (16px size) and 13px text.
- **Active State:** A solid blue background with white text/icon.

### Control Mapping
- **Input Fields:** Sleek, dark-mode fields that highlight Blue when focused. 
- **Mapping Slots:** Use a "Pill" shape for the physical key/button label, paired with a standard input box on the right.

### Cards & Grouping
- **Inspector Panels:** Grouped settings should be placed within rounded-rect containers with a 1px border. Use "Label-Caps" for section headers (e.g., "ASIGNACIÓN DE BOTONES").

### Lists & Inputs
- **Segmented Controls:** Used for switching between "Configuration" and "View" modes, strictly following the macOS native appearance (recessed track, sliding active thumb).